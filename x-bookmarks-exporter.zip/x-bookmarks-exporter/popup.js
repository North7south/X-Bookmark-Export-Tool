(function () {
  "use strict";

  const STORAGE_KEY = "xBookmarksExporterData";

  const countEl = document.getElementById("count");
  const exportBtn = document.getElementById("exportBtn");
  const refreshBtn = document.getElementById("refreshBtn");
  const clearBtn = document.getElementById("clearBtn");
  const hintEl = document.getElementById("hint");
  const errEl = document.getElementById("err");

  function showErr(msg) {
    errEl.textContent = msg || "";
    errEl.hidden = !msg;
  }

  function escapeCsvField(s) {
    if (s == null) return "";
    const str = String(s);
    if (/[",\r\n]/.test(str)) {
      return `"${str.replace(/"/g, '""')}"`;
    }
    return str;
  }

  function buildCsv(rows) {
    const header = ["tweet_url", "published_at", "text"];
    const lines = [
      header.map(escapeCsvField).join(","),
      ...rows.map((r) =>
        [
          escapeCsvField(r.url),
          escapeCsvField(r.published_at),
          escapeCsvField(r.text),
        ].join(",")
      ),
    ];
    return "\uFEFF" + lines.join("\r\n");
  }

  async function loadFromStorage() {
    const data = await chrome.storage.local.get(STORAGE_KEY);
    const payload = data[STORAGE_KEY];
    if (!payload || !Array.isArray(payload.tweets)) {
      countEl.textContent = "0";
      hintEl.textContent = "尚未有数据：请先打开书签页。";
      return { tweets: [], count: 0 };
    }
    countEl.textContent = String(payload.count ?? payload.tweets.length);
    const t = new Date(payload.updatedAt || 0);
    hintEl.textContent = t.getTime()
      ? `上次更新：${t.toLocaleString()}`
      : "";
    return { tweets: payload.tweets, count: payload.tweets.length };
  }

  async function tryRefreshFromTab() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) return;
    try {
      const res = await chrome.tabs.sendMessage(tab.id, { type: "GET_STATS" });
      if (res?.onBookmarks && typeof res.count === "number") {
        hintEl.textContent = `当前标签页书签内已识别约 ${res.count} 条（与缓存合并请以导出为准）。`;
      }
    } catch {
      /* content script not injected */
    }
  }

  exportBtn.addEventListener("click", async () => {
    showErr("");
    exportBtn.disabled = true;
    try {
      const { tweets } = await loadFromStorage();
      if (!tweets.length) {
        showErr("没有可导出的数据。请先在书签页面停留一段时间。");
        return;
      }
      const rows = tweets.map((t) => ({
        url: t.url || "",
        published_at: t.published_at || "",
        text: t.text || "",
      }));
      const csv = buildCsv(rows);
      const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `x-bookmarks-${new Date().toISOString().slice(0, 19).replace(/:/g, "-")}.csv`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (e) {
      showErr(e?.message || String(e));
    } finally {
      exportBtn.disabled = false;
    }
  });

  refreshBtn.addEventListener("click", async () => {
    showErr("");
    await loadFromStorage();
    await tryRefreshFromTab();
  });

  clearBtn.addEventListener("click", async () => {
    showErr("");
    await chrome.storage.local.remove(STORAGE_KEY);
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab?.id) {
      try {
        await chrome.tabs.sendMessage(tab.id, { type: "CLEAR_CACHE" });
      } catch {
        /* ignore */
      }
    }
    await loadFromStorage();
  });

  loadFromStorage().then(() => tryRefreshFromTab());
})();
