(function () {
  "use strict";

  const STORAGE_KEY = "xBookmarksExporterData";
  const SCROLL_INTERVAL_MS = 900;
  const IDLE_ROUNDS_BEFORE_STOP = 6;

  /** @type {ReturnType<typeof setInterval> | null} */
  let scrollTimer = null;
  let idleRounds = 0;
  let lastScrollHeight = 0;
  /** @type {Map<string, { url: string, text: string, published_at: string }>} */
  const tweetsById = new Map();

  /**
   * X 在指向该条 status 的链接内嵌 <time datetime="ISO8601">。
   * @param {Element} article
   * @param {string} statusId
   * @returns {string}
   */
  function extractPublishedAt(article, statusId) {
    if (!statusId) return "";
    const anchors = article.querySelectorAll(`a[href*="/status/${statusId}"]`);
    for (const a of anchors) {
      const timeEl = a.querySelector("time[datetime]");
      if (timeEl) {
        const dt = timeEl.getAttribute("datetime");
        if (dt && dt.trim()) return dt.trim();
      }
    }
    const first = article.querySelector("time[datetime]");
    if (first) {
      const dt = first.getAttribute("datetime");
      if (dt && dt.trim()) return dt.trim();
    }
    return "";
  }

  function getScrollableElement() {
    const primary = document.querySelector('[data-testid="primaryColumn"]');
    if (primary) {
      const scrollable = primary.querySelector('[style*="overflow"]') || primary;
      if (scrollable.scrollHeight > scrollable.clientHeight + 50) return scrollable;
    }
    const main = document.querySelector('main[role="main"]');
    if (main && main.scrollHeight > main.clientHeight + 50) return main;
    return document.scrollingElement || document.documentElement;
  }

  function extractStatusIdFromHref(href) {
    if (!href || typeof href !== "string") return null;
    try {
      const u = href.startsWith("http") ? new URL(href) : new URL(href, "https://x.com");
      const m = u.pathname.match(/\/status\/(\d+)/);
      return m ? m[1] : null;
    } catch {
      return null;
    }
  }

  function normalizeTweetUrl(href) {
    const id = extractStatusIdFromHref(href);
    if (!id) return null;
    try {
      const u = href.startsWith("http") ? new URL(href) : new URL(href, "https://x.com");
      const host = u.hostname.replace(/^www\./, "");
      const base = host.includes("twitter.com") ? "https://twitter.com" : "https://x.com";
      const pathMatch = u.pathname.match(/^(\/[^/]+)\/status\/\d+/);
      const path = pathMatch ? pathMatch[0] : `/i/status/${id}`;
      return `${base}${path}`;
    } catch {
      return `https://x.com/i/status/${id}`;
    }
  }

  function scrapeVisibleTweets() {
    const articles = document.querySelectorAll('article[data-testid="tweet"]');
    let added = 0;

    articles.forEach((article) => {
      const textEl = article.querySelector('[data-testid="tweetText"]');
      const text = textEl ? textEl.innerText.trim().replace(/\s+/g, " ") : "";

      const links = article.querySelectorAll('a[href*="/status/"]');
      let url = null;
      let id = null;
      for (const a of links) {
        const href = a.getAttribute("href");
        const nid = extractStatusIdFromHref(href);
        if (nid) {
          const norm = normalizeTweetUrl(href);
          if (norm) {
            url = norm;
            id = nid;
            break;
          }
        }
      }

      if (!id || !url) return;
      const published_at = extractPublishedAt(article, id);
      if (!tweetsById.has(id)) {
        tweetsById.set(id, { url, text, published_at });
        added += 1;
      } else {
        const prev = tweetsById.get(id);
        const nextPublished =
          published_at || prev.published_at || "";
        if (text && (!prev.text || prev.text.length < text.length)) {
          tweetsById.set(id, { url, text, published_at: nextPublished });
        } else if (published_at && !prev.published_at) {
          tweetsById.set(id, {
            url: prev.url,
            text: prev.text,
            published_at: nextPublished,
          });
        }
      }
    });

    return added;
  }

  async function persist() {
    const list = Array.from(tweetsById.entries()).map(([id, v]) => ({
      id,
      url: v.url,
      text: v.text,
      published_at: v.published_at || "",
    }));
    const payload = {
      tweets: list,
      count: list.length,
      updatedAt: Date.now(),
      pageUrl: location.href,
    };
    try {
      await chrome.storage.local.set({ [STORAGE_KEY]: payload });
    } catch (e) {
      console.warn("[x-bookmarks-exporter] storage write failed", e);
    }
  }

  let persistDebounce = null;
  function schedulePersist() {
    if (persistDebounce) clearTimeout(persistDebounce);
    persistDebounce = setTimeout(() => {
      persistDebounce = null;
      persist();
    }, 400);
  }

  function tickScroll() {
    const el = getScrollableElement();
    const h = el.scrollHeight;
    scrapeVisibleTweets();
    schedulePersist();

    el.scrollTop = h;

    const nearBottom = el.scrollTop + el.clientHeight >= h - 80;
    if (h === lastScrollHeight && nearBottom) {
      idleRounds += 1;
      if (idleRounds >= IDLE_ROUNDS_BEFORE_STOP && scrollTimer) {
        clearInterval(scrollTimer);
        scrollTimer = null;
        persist();
      }
    } else {
      idleRounds = 0;
    }
    lastScrollHeight = h;
  }

  function startAutoScroll() {
    scrapeVisibleTweets();
    schedulePersist();
    if (scrollTimer) return;
    idleRounds = 0;
    lastScrollHeight = 0;
    scrollTimer = setInterval(tickScroll, SCROLL_INTERVAL_MS);
  }

  const mo = new MutationObserver(() => {
    scrapeVisibleTweets();
    schedulePersist();
  });
  const root =
    document.querySelector('[data-testid="primaryColumn"]') ||
    document.querySelector("main") ||
    document.body;
  mo.observe(root, { childList: true, subtree: true });

  startAutoScroll();

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg?.type === "GET_STATS") {
      sendResponse({
        count: tweetsById.size,
        onBookmarks: /\/i\/bookmarks/.test(location.pathname),
      });
      return true;
    }
    if (msg?.type === "CLEAR_CACHE") {
      tweetsById.clear();
      persist().then(() => sendResponse({ ok: true }));
      return true;
    }
    return false;
  });
})();
